#!/usr/bin/env python3
"""
Xteink Hub - one app on your Android phone (Termux) for the Xteink X4 + CrossPoint:
  * OPDS server       -> browse & download on the X4 (File Transfer -> OPDS Browser)
  * Live articles     -> sci-fi + science RSS feeds turned into EPUB digests
  * Free books        -> public-domain sci-fi / science from Project Gutenberg
  * KOReader sync     -> reading-progress sync server for CrossPoint's KOReader Sync
  * Phone dashboard   -> http://127.0.0.1:8080  (buttons for everything)
"""
import datetime as dt
import hashlib
import json
import os
import re
import socket
import subprocess
import threading
import time
import zipfile
from collections import deque
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote, urlparse, parse_qs, unquote
from xml.sax.saxutils import escape

import feedparser
import requests
from bs4 import BeautifulSoup

HOME = Path(os.environ.get("XHUB_HOME", str(Path.home() / "xteink-hub"))).expanduser()
PORT = int(os.environ.get("XHUB_PORT", "8080"))
REMOTE_ADMIN = os.environ.get("XHUB_REMOTE_ADMIN") == "1"   # allow dashboard buttons from other devices

CATS = {"scifi": "Sci-Fi", "science": "Science", "other": "Other"}
DEFAULT_CONFIG = {
    "feeds": [
        {"cat": "scifi", "name": "Reactor (Tor.com)", "url": "https://reactormag.com/feed/"},
        {"cat": "scifi", "name": "Clarkesworld", "url": "https://clarkesworldmagazine.com/feed/"},
        {"cat": "scifi", "name": "Strange Horizons", "url": "https://strangehorizons.com/feed/"},
        {"cat": "scifi", "name": "Lightspeed", "url": "https://www.lightspeedmagazine.com/feed/"},
        {"cat": "science", "name": "Quanta Magazine", "url": "https://www.quantamagazine.org/feed/"},
        {"cat": "science", "name": "Ars Technica Science", "url": "https://feeds.arstechnica.com/arstechnica/science"},
        {"cat": "science", "name": "NASA", "url": "https://www.nasa.gov/feed/"},
        {"cat": "science", "name": "Phys.org", "url": "https://phys.org/rss-feed/"},
        {"cat": "science", "name": "ScienceDaily", "url": "https://www.sciencedaily.com/rss/all.xml"},
    ],
    "book_topics": [
        {"cat": "scifi", "topic": "science fiction"},
        {"cat": "scifi", "topic": "science fiction short stories"},
        {"cat": "science", "topic": "science"},
        {"cat": "science", "topic": "astronomy"},
        {"cat": "science", "topic": "natural history"},
    ],
    "articles_per_feed": 8,
    "books_per_topic": 15,
    "keep_days": 7,
    "auto_refresh_hours": 6,
    "allow_sync_signup": True,
    "auto_setup_x4": True,
    "auto_setup_sync": True,
    "sync_user": "xteink",
    "sync_password": "",
}
SYNC_PORT = 17200          # KOReader sync also served here (kosync's usual port)
X4 = {"ip": None, "msg": "Waiting for the X4…", "ok": False, "phone_ip": None}

UA = ("Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36")
HEADERS = {"User-Agent": UA,
           "Accept": "application/rss+xml, application/atom+xml, application/xml;q=0.9, "
                     "text/xml;q=0.9, text/html;q=0.8, */*;q=0.7",
           "Accept-Language": "en-US,en;q=0.9"}
SESSION = requests.Session()
SESSION.headers.update(HEADERS)

LOG = deque(maxlen=300)
STATE = {"busy": False, "task": "", "last_update": None, "last_attempt": 0}
LOCK = threading.Lock()
DB_LOCK = threading.Lock()


# ------------------------------------------------------------------ basics
def log(*a):
    line = time.strftime("%H:%M:%S ") + " ".join(str(x) for x in a)
    LOG.append(line)
    print(line, flush=True)


def now_iso():
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-") or "x"


def short(e):
    return f"{type(e).__name__}: {str(e)[:160]}"


def _via_requests(url):
    r = SESSION.get(url, timeout=(12, 40), allow_redirects=True)
    r.raise_for_status()
    return r.content


def _via_urllib(url):
    import ssl
    import urllib.request
    import certifi
    ctx = ssl.create_default_context(cafile=certifi.where())
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=40, context=ctx) as f:
        return f.read()


def _via_android(url):
    """Android's own HTTP stack (system DNS, Private DNS, certificates, proxies)."""
    from java import jarray, jbyte
    from java.io import ByteArrayOutputStream
    from java.net import URL
    for _ in range(5):                       # follow redirects, incl. http <-> https
        conn = URL(url).openConnection()
        conn.setConnectTimeout(15000)
        conn.setReadTimeout(40000)
        conn.setInstanceFollowRedirects(False)
        for k, v in HEADERS.items():
            conn.setRequestProperty(k, v)
        code = conn.getResponseCode()
        if code in (301, 302, 303, 307, 308):
            loc = conn.getHeaderField("Location")
            conn.disconnect()
            if not loc:
                raise RuntimeError(f"HTTP {code} without Location")
            from urllib.parse import urljoin
            url = urljoin(url, str(loc))
            continue
        if code >= 400:
            conn.disconnect()
            raise RuntimeError(f"HTTP {code}")
        ins = conn.getInputStream()
        bos = ByteArrayOutputStream()
        buf = jarray(jbyte)(32768)
        while True:
            n = ins.read(buf)
            if n < 0:
                break
            bos.write(buf, 0, n)
        ins.close()
        conn.disconnect()
        return bytes(bos.toByteArray())
    raise RuntimeError("too many redirects")


FETCHERS = [("python", _via_requests), ("android", _via_android), ("urllib", _via_urllib)]
_PREFERRED = {"name": None}


def fetch(url):
    """Download url, trying several network stacks; remembers which one works."""
    order = sorted(FETCHERS, key=lambda f: f[0] != _PREFERRED["name"])
    errors = []
    for name, fn in order:
        try:
            data = fn(url)
            if _PREFERRED["name"] != name:
                _PREFERRED["name"] = name
                log(f"   (using {name} network stack)")
            return data
        except ModuleNotFoundError:
            continue                     # android stack when not on Android
        except Exception as e:
            errors.append(f"{name}: {short(e)}")
    raise RuntimeError(" | ".join(errors) or "no network stack available")


class _Resp:
    def __init__(self, data):
        self.content = data
        self.text = data.decode("utf-8", "replace")

    def json(self):
        return json.loads(self.content)


def get(url, **kw):
    return _Resp(fetch(url))


def dirs():
    for d in ("files/articles", "files/books", "files/mine", "meta/articles",
              "meta/books", "meta/mine", "opds"):
        (HOME / d).mkdir(parents=True, exist_ok=True)


def load_json(path, default):
    try:
        return json.loads(Path(path).read_text())
    except Exception:
        return default


def save_json(path, data):
    tmp = Path(str(path) + ".tmp")
    tmp.write_text(json.dumps(data, indent=1))
    tmp.replace(path)


def cfg():
    c = load_json(HOME / "config.json", None)
    if not c:
        c = json.loads(json.dumps(DEFAULT_CONFIG))
        save_json(HOME / "config.json", c)
    for k, v in DEFAULT_CONFIG.items():
        c.setdefault(k, v)
    return c


# ------------------------------------------------------------------ article extraction
def clean_blocks(root):
    out = []
    if root is None:
        return out
    for el in root.find_all(["h2", "h3", "h4", "p", "blockquote", "li"]):
        if el.name in ("blockquote", "li") and el.find("p"):
            continue
        text = " ".join(el.get_text(" ", strip=True).split())
        if not text:
            continue
        if el.name.startswith("h"):
            kind = "h"
        elif el.name == "blockquote":
            kind = "q"
        elif el.name == "li":
            kind, text = "p", "• " + text
        else:
            if len(text) < 25:
                continue
            kind = "p"
        if out and out[-1] == (kind, text):
            continue
        out.append((kind, text))
    return out


def extract_article(url, fallback_html):
    try:
        soup = BeautifulSoup(get(url).text, "html.parser")
        for t in soup(["script", "style", "nav", "header", "footer", "aside", "form",
                       "figure", "noscript", "iframe", "button"]):
            t.decompose()
        box = soup.find("article") or soup.find("main") or soup.body
        blocks = clean_blocks(box)
        if sum(len(t) for _, t in blocks) > 800:
            return blocks
    except Exception as e:
        log("   full article unavailable, using feed text")
    return clean_blocks(BeautifulSoup(fallback_html or "", "html.parser"))


# ------------------------------------------------------------------ EPUB writer
CSS = ("body{font-family:serif;line-height:1.4;margin:0 .5em}h1,h2,h3{font-family:sans-serif}"
       "p{margin:.6em 0;text-align:left}blockquote{margin:.8em 1.2em;font-style:italic}")


def blocks_to_xhtml(title, blocks):
    body = [f"<h2>{escape(title)}</h2>"]
    for kind, text in blocks:
        t = escape(text)
        body.append(f"<h3>{t}</h3>" if kind == "h" else
                    f"<blockquote><p>{t}</p></blockquote>" if kind == "q" else f"<p>{t}</p>")
    return ('<?xml version="1.0" encoding="utf-8"?><!DOCTYPE html>'
            '<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">'
            f'<head><title>{escape(title)}</title><link rel="stylesheet" type="text/css" href="style.css"/>'
            f'</head><body>{"".join(body)}</body></html>')


def build_epub(path, title, author, chapters):
    uid = "urn:xteink:" + hashlib.sha1((title + author).encode()).hexdigest()[:16]
    items, spine, navpoints, navli = [], [], [], []
    for i, (ct, _) in enumerate(chapters, 1):
        items.append(f'<item id="c{i}" href="c{i}.xhtml" media-type="application/xhtml+xml"/>')
        spine.append(f'<itemref idref="c{i}"/>')
        navpoints.append(f'<navPoint id="n{i}" playOrder="{i}"><navLabel><text>{escape(ct)}</text>'
                         f'</navLabel><content src="c{i}.xhtml"/></navPoint>')
        navli.append(f'<li><a href="c{i}.xhtml">{escape(ct)}</a></li>')
    opf = ('<?xml version="1.0" encoding="utf-8"?>'
           '<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="uid">'
           '<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">'
           f'<dc:identifier id="uid">{uid}</dc:identifier><dc:title>{escape(title)}</dc:title>'
           f'<dc:creator>{escape(author)}</dc:creator><dc:language>en</dc:language>'
           f'<meta property="dcterms:modified">{now_iso()}</meta></metadata><manifest>'
           '<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>'
           '<item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>'
           '<item id="css" href="style.css" media-type="text/css"/>'
           + "".join(items) + '</manifest><spine toc="ncx">' + "".join(spine) + '</spine></package>')
    ncx = ('<?xml version="1.0" encoding="utf-8"?><ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" '
           f'version="2005-1"><head><meta name="dtb:uid" content="{uid}"/></head><docTitle><text>'
           f'{escape(title)}</text></docTitle><navMap>' + "".join(navpoints) + '</navMap></ncx>')
    nav = ('<?xml version="1.0" encoding="utf-8"?><!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml" '
           f'xmlns:epub="http://www.idpf.org/2007/ops"><head><title>{escape(title)}</title></head><body>'
           '<nav epub:type="toc"><h1>Contents</h1><ol>' + "".join(navli) + '</ol></nav></body></html>')
    container = ('<?xml version="1.0"?><container version="1.0" '
                 'xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles>'
                 '<rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>'
                 '</rootfiles></container>')
    tmp = Path(str(path) + ".part")
    D = zipfile.ZIP_DEFLATED
    with zipfile.ZipFile(tmp, "w") as z:
        z.writestr("mimetype", "application/epub+zip", compress_type=zipfile.ZIP_STORED)
        z.writestr("META-INF/container.xml", container, compress_type=D)
        z.writestr("OEBPS/content.opf", opf, compress_type=D)
        z.writestr("OEBPS/toc.ncx", ncx, compress_type=D)
        z.writestr("OEBPS/nav.xhtml", nav, compress_type=D)
        z.writestr("OEBPS/style.css", CSS, compress_type=D)
        for i, (ct, blocks) in enumerate(chapters, 1):
            z.writestr(f"OEBPS/c{i}.xhtml", blocks_to_xhtml(ct, blocks), compress_type=D)
    tmp.replace(path)


# ------------------------------------------------------------------ content updates
def write_meta(kind, fname, data):
    save_json(HOME / "meta" / kind / (fname + ".json"), data)


def update_articles(c):
    today = dt.date.today().isoformat()
    ok = 0
    for f in c["feeds"]:
        name, url, cat = f["name"], f["url"], f.get("cat", "other")
        fname = f"{slug(name)}-{today}.epub"
        try:
            log("Feed:", name)
            parsed = feedparser.parse(get(url).content)
            if not parsed.entries:
                log("   feed had no entries (site may block apps, or URL changed)")
                continue
            chapters = []
            for e in parsed.entries[: int(c["articles_per_feed"])]:
                fb = (e.get("content") or [{}])[0].get("value") or e.get("summary", "")
                blocks = extract_article(e.get("link", ""), fb)
                if not blocks:
                    txt = " ".join(BeautifulSoup(fb or "", "html.parser").get_text(" ").split())
                    blocks = [("p", txt)] if txt else []
                    if e.get("link"):
                        blocks.append(("p", "Read online: " + e["link"]))
                if blocks:
                    chapters.append((e.get("title", "Untitled"), blocks))
                time.sleep(1)
            if not chapters:
                log("   nothing usable, skipped")
                continue
            build_epub(HOME / "files/articles" / fname, f"{name} - {today}", name, chapters)
            write_meta("articles", fname, {"title": f"{name} - {today}", "author": name, "cat": cat,
                                           "date": today, "summary": f"{len(chapters)} articles"})
            log(f"   built ({len(chapters)} articles)")
            ok += 1
        except Exception as e:
            log("   feed failed:", short(e))
    cutoff = (dt.date.today() - dt.timedelta(days=int(c["keep_days"]))).isoformat()
    for m in (HOME / "meta/articles").glob("*.json"):
        if load_json(m, {}).get("date", "9999") < cutoff:
            (HOME / "files/articles" / m.name[:-5]).unlink(missing_ok=True)
            m.unlink(missing_ok=True)
    return ok


def update_books(c):
    ok = 0
    for bt in c["book_topics"]:
        topic, cat = bt["topic"], bt.get("cat", "other")
        url = "https://gutendex.com/books/?languages=en&sort=popular&topic=" + quote(topic)
        got = 0
        log("Books:", topic)
        while url and got < int(c["books_per_topic"]):
            try:
                data = get(url).json()
                ok += 1
            except Exception as e:
                log("   gutendex failed:", short(e))
                break
            for b in data.get("results", []):
                if got >= int(c["books_per_topic"]):
                    break
                epub = b.get("formats", {}).get("application/epub+zip")
                if not epub:
                    continue
                got += 1
                fname = f"pg{b['id']}.epub"
                fpath = HOME / "files/books" / fname
                if fpath.exists():
                    continue
                try:
                    tmp = Path(str(fpath) + ".part")
                    tmp.write_bytes(get(epub).content)
                    tmp.replace(fpath)
                    author = b["authors"][0]["name"] if b.get("authors") else "Unknown"
                    write_meta("books", fname, {"title": b["title"], "author": author, "cat": cat})
                    log("   +", b["title"][:60])
                    time.sleep(1)
                except Exception as e:
                    log("   download failed:", b.get("id"), short(e))
            url = data.get("next")
    return ok


def run_update(what="all"):
    if not LOCK.acquire(blocking=False):
        return False

    def work():
        try:
            STATE.update(busy=True, task=f"Updating {what}")
            c = cfg()
            STATE["last_attempt"] = time.time()
            good = 0
            if what in ("all", "articles"):
                good += update_articles(c)
            if what in ("all", "books"):
                good += update_books(c)
            build_catalog()
            if good:
                STATE["last_update"] = time.time()
                save_json(HOME / "state.json", {"last_update": STATE["last_update"]})
                log("Update finished.")
            else:
                log("Update failed: no internet? Will retry automatically in 15 minutes.")
        except Exception as e:
            log("Update failed:", e)
        finally:
            STATE.update(busy=False, task="")
            LOCK.release()

    threading.Thread(target=work, daemon=True).start()
    return True


def auto_refresher():
    while True:
        time.sleep(60)
        h = float(cfg().get("auto_refresh_hours") or 0)
        last = STATE.get("last_update") or 0
        if (h > 0 and time.time() - last >= h * 3600 and not STATE["busy"]
                and time.time() - STATE["last_attempt"] >= 900):
            log("Auto refresh")
            run_update("all")


# ------------------------------------------------------------------ OPDS
NAV_T = "application/atom+xml;profile=opds-catalog;kind=navigation"
ACQ_T = "application/atom+xml;profile=opds-catalog;kind=acquisition"


def atom_feed(title, fid, href, kind_t, entries):
    return ('<?xml version="1.0" encoding="utf-8"?>'
            '<feed xmlns="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/terms/">'
            f'<id>urn:xteink:{fid}</id><title>{escape(title)}</title><updated>{now_iso()}</updated>'
            '<author><name>Xteink Hub</name></author>'
            f'<link rel="self" href="{href}" type="{kind_t}"/>'
            f'<link rel="start" href="/opds.xml" type="{NAV_T}"/>' + "".join(entries) + '</feed>')


def load_meta(kind):
    items = []
    for m in (HOME / "meta" / kind).glob("*.json"):
        fname = m.name[:-5]
        if (HOME / "files" / kind / fname).exists():
            d = load_json(m, None)
            if d:
                items.append((fname, d))
    return items


def sections():
    out = []
    for kind, label in (("articles", "Articles"), ("books", "Books")):
        items = load_meta(kind)
        for cat, cname in CATS.items():
            sel = [(f, m) for f, m in items if m.get("cat") == cat]
            if cat == "other" and not sel:
                continue
            if kind == "articles":
                sel.sort(key=lambda x: (x[1].get("date", ""), x[1]["title"]), reverse=True)
            else:
                sel.sort(key=lambda x: x[1]["title"].lower())
            out.append((kind, f"{kind}-{cat}", f"{label}: {cname}", sel))
    mine = sorted(load_meta("mine"), key=lambda x: x[1]["title"].lower())
    out.append(("mine", "mine", "My uploads", mine))
    return out


def build_catalog():
    dirs()
    root = []
    for kind, name, title, sel in sections():
        href = f"/opds/{name}.xml"
        entries = [(f'<entry><title>{escape(m["title"])}</title><id>urn:xteink:{kind}:{escape(f)}</id>'
                    f'<updated>{now_iso()}</updated><author><name>{escape(m.get("author", ""))}</name></author>'
                    f'<content type="text">{escape(m.get("summary", ""))}</content>'
                    f'<link rel="http://opds-spec.org/acquisition" href="/files/{kind}/{quote(f)}" '
                    'type="application/epub+zip"/></entry>') for f, m in sel]
        (HOME / "opds" / f"{name}.xml").write_text(atom_feed(title, name, href, ACQ_T, entries), encoding="utf-8")
        root.append(f'<entry><title>{escape(title)}</title><id>urn:xteink:nav:{name}</id>'
                    f'<updated>{now_iso()}</updated><content type="text">{len(sel)} items</content>'
                    f'<link rel="subsection" href="{href}" type="{ACQ_T}"/></entry>')
    (HOME / "opds.xml").write_text(atom_feed("Xteink Hub", "root", "/opds.xml", NAV_T, root), encoding="utf-8")


# ------------------------------------------------------------------ KOReader sync (kosync protocol)
def sync_db():
    return load_json(HOME / "sync.json", {"users": {}, "progress": {}})


def sync_auth(h):
    user, key = h.headers.get("x-auth-user"), h.headers.get("x-auth-key")
    if not user or not key:
        return None
    db = sync_db()
    return user if db["users"].get(user) == key else None


# ------------------------------------------------------------------ network info
HOTSPOT_NAMES = ("ap", "swlan", "wlan1", "wlan2", "softap", "rndis", "ncm", "bt-pan", "tether")
_IFACE_ERR = {"logged": False}


def _ips_java():
    from java.net import NetworkInterface
    from java.util import Collections
    out = []
    for ni in Collections.list(NetworkInterface.getNetworkInterfaces()):
        try:
            if not ni.isUp() or ni.isLoopback():
                continue
        except Exception:
            pass
        for a in Collections.list(ni.getInetAddresses()):
            h = str(a.getHostAddress())
            if ":" not in h:
                out.append((str(ni.getName()), h))
    return out


def _ips_ioctl():
    """Ask the kernel for each interface's address (works without netlink)."""
    import fcntl
    import struct
    names = set()
    try:
        names.update(n for _, n in socket.if_nameindex())
    except Exception:
        pass
    names.update(["ap0", "ap1", "swlan0", "wlan0", "wlan1", "wlan2", "softap0", "rndis0",
                  "ncm0", "bt-pan", "eth0", "usb0"])
    out = []
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    for n in names:
        try:
            r = fcntl.ioctl(s.fileno(), 0x8915, struct.pack("256s", n.encode()[:15]))  # SIOCGIFADDR
            out.append((n, socket.inet_ntoa(r[20:24])))
        except Exception:
            pass
    s.close()
    return out


def _ips_route_probe():
    """Find local subnets by asking the kernel which source address it would use.
    UDP connect() sends nothing; it only does a route lookup."""
    out = []
    targets = [f"192.168.{x}.1" for x in range(256)] + [f"172.{x}.0.1" for x in range(16, 32)] \
        + ["10.0.0.1", "10.42.0.1", "10.0.2.1", "10.10.10.1"]
    for t in targets:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect((t, 9))
            me = s.getsockname()[0]
            if me.rsplit(".", 1)[0] == t.rsplit(".", 1)[0]:
                out.append(("hotspot", me))
        except Exception:
            pass
        finally:
            s.close()
    return out


def local_ips():
    found = []
    for name, fn in (("java", _ips_java), ("ioctl", _ips_ioctl), ("route", _ips_route_probe)):
        try:
            found += fn()
        except Exception as e:
            if not _IFACE_ERR["logged"]:
                log(f"(network scan via {name} unavailable: {short(e)})")
    _IFACE_ERR["logged"] = True
    if not any(_private(ip) for _, ip in found):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("10.255.255.255", 1))
            found.append(("network", s.getsockname()[0]))
            s.close()
        except Exception:
            pass
    res, seen = [], set()
    for iface, ip in found:
        if ip in seen or ip.startswith("127.") or ip.startswith("0."):
            continue
        if iface.startswith(("rmnet", "ccmni", "tun", "dummy", "v4-", "clat")):
            continue
        seen.add(ip)
        hotspot = iface.startswith(HOTSPOT_NAMES) or iface == "hotspot" or \
            bool(re.match(r"192\.168\.\d+\.1$", ip))
        res.append({"iface": iface, "ip": ip, "hotspot": hotspot})
    # drop mobile-data / CGNAT addresses when a real local address exists
    if any(_private(r["ip"]) for r in res):
        res = [r for r in res if _private(r["ip"])]
    if not res:
        res.append({"iface": "hotspot (guess)", "ip": "192.168.43.1", "hotspot": True})
    res.sort(key=lambda r: not r["hotspot"])
    return res


# ------------------------------------------------------------------ X4 auto-setup
# CrossPoint's File Transfer mode runs a web server on port 80 with /api/opds and
# /api/settings, and answers "hello" on UDP 8134. We find it and write our server in.
def _private(ip):
    try:
        a = [int(x) for x in ip.split(".")]
    except ValueError:
        return False
    return a[0] == 10 or (a[0] == 172 and 16 <= a[1] <= 31) or (a[0] == 192 and a[1] == 168)


def discover_x4():
    mine = [i["ip"] for i in local_ips() if i["iface"] != "hotspot (guess)" and _private(i["ip"])]
    if not mine:
        return set()
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    s.settimeout(0.25)
    try:
        s.sendto(b"hello", ("255.255.255.255", 8134))
    except Exception:
        pass
    for ip in mine:
        pre = ip.rsplit(".", 1)[0]
        for n in list(range(1, 255)) + [255]:
            t = f"{pre}.{n}"
            if t != ip:
                try:
                    s.sendto(b"hello", (t, 8134))
                except Exception:
                    pass
    found, end = set(), time.time() + 1.5
    while time.time() < end:
        try:
            data, addr = s.recvfrom(512)
            if data.lower().startswith(b"crosspoint"):
                found.add(addr[0])
        except socket.timeout:
            continue
        except Exception:
            break
    s.close()
    return found


def phone_ip_for(x4ip):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((x4ip, 9))
        me = s.getsockname()[0]
        s.close()
        if me.rsplit(".", 1)[0] == x4ip.rsplit(".", 1)[0]:
            return me
    except Exception:
        pass
    pre = x4ip.rsplit(".", 1)[0] + "."
    for i in local_ips():
        if i["ip"].startswith(pre):
            return i["ip"]
    return None


def configure_x4(ip):
    c = cfg()
    web = requests.Session()
    web.trust_env = False
    base = f"http://{ip}"
    st = web.get(base + "/api/status", timeout=5).json()
    phone = phone_ip_for(ip)
    if not phone:
        raise RuntimeError("phone and X4 are on different networks")
    url = f"http://{phone}:{PORT}/opds.xml"
    servers = web.get(base + "/api/opds", timeout=5).json()
    hub = [x for x in servers if x.get("name") == "Xteink Hub" or f":{PORT}/opds.xml" in str(x.get("url"))]
    if hub and hub[0].get("url") == url:
        log(f"X4 ({ip}): OPDS server already set")
    else:
        body = {"name": "Xteink Hub", "url": url, "username": "", "password": ""}
        if hub:
            body["index"] = hub[0]["index"]
        elif len(servers) >= 8:
            raise RuntimeError("the X4 already has 8 OPDS servers; delete one")
        web.post(base + "/api/opds", json=body, timeout=8).raise_for_status()
        log(f"X4 ({ip}): OPDS server written -> {url}")
    msg = ""
    if c.get("auto_setup_sync"):
        try:
            msg = configure_sync(web, base, phone, c)
        except Exception as e:
            msg = "sync not set automatically: " + str(e)[:80]
            log("X4 sync setup:", e)
    X4.update(ip=ip, phone_ip=phone, ok=True,
              msg=f"X4 ({st.get('device', 'X4')}) at {ip} is set up ✓ "
                  "Exit File Transfer on the X4 and open OPDS Browser → Xteink Hub."
                  + (f" ({msg})" if msg else ""))


def configure_sync(web, base, phone, c):
    """Point CrossPoint's KOReader Sync at this phone and create a matching account."""
    if not c.get("sync_password"):
        c["sync_password"] = hashlib.sha1(os.urandom(16)).hexdigest()[:10]
        save_json(HOME / "config.json", c)
    user, pw = c["sync_user"], c["sync_password"]
    with DB_LOCK:
        db = sync_db()
        db["users"][user] = hashlib.md5(pw.encode()).hexdigest()
        save_json(HOME / "sync.json", db)
    items = web.get(base + "/api/settings", timeout=8).json()
    keys = [str(i.get("key") or i.get("id") or "") for i in items if isinstance(i, dict)]
    pick = lambda *w: next((k for k in keys if k.lower().startswith("ko") and all(x in k.lower() for x in w)), None)
    upd = {}
    k_url, k_user, k_pass = pick("url") or pick("server"), pick("user"), pick("pass")
    if k_url:
        upd[k_url] = f"http://{phone}:{SYNC_PORT}"
    if k_user:
        upd[k_user] = user
    if k_pass:
        upd[k_pass] = pw
    if not upd:
        return "enter sync details on the X4 manually"
    web.post(base + "/api/settings", json=upd, timeout=8).raise_for_status()
    log(f"X4: KOReader sync set ({', '.join(upd)})")
    return "KOReader sync set" if (k_user and k_pass) else "sync URL set; enter user/password on the X4"


def x4_watcher():
    done = {}          # x4 ip -> phone ip it was configured with
    while True:
        try:
            if cfg().get("auto_setup_x4"):
                nets = [i["ip"] for i in local_ips() if _private(i["ip"]) and i["iface"] != "hotspot (guess)"]
                if not X4["ok"] and not X4["ip"]:
                    X4["msg"] = ("Waiting for the X4… (searching " + ", ".join(n.rsplit(".", 1)[0] + ".x" for n in nets) + ")"
                                 if nets else "Hotspot not detected: turn on this phone's hotspot.")
                found = discover_x4()
                for ip in found:
                    if done.get(ip) != phone_ip_for(ip):
                        try:
                            configure_x4(ip)
                            done[ip] = phone_ip_for(ip)
                        except Exception as e:
                            if ip.startswith("192.168.4.") or "abort" in str(e).lower():
                                msg = ("Your phone is connected to the X4's own Wi-Fi (Create hotspot). "
                                       "That can't work: disconnect the phone from it, turn ON this phone's "
                                       "hotspot, then on the X4 choose File Transfer → Join network → your hotspot.")
                            else:
                                msg = f"Found X4 at {ip} but setup failed: {e}"
                            X4.update(ip=ip, ok=False, msg=msg)
                            log("X4 setup failed:", e)
                for ip in list(done):
                    if ip not in found:
                        done.pop(ip)   # re-check next time it appears
        except Exception as e:
            log("X4 watcher:", e)
        time.sleep(4)


# ------------------------------------------------------------------ HTTP
class Handler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map,
                      ".epub": "application/epub+zip",
                      ".xml": "application/atom+xml;profile=opds-catalog"}

    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(HOME), **kw)

    def log_message(self, fmt, *args):
        pass

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    # helpers
    def send_json(self, code, obj, ctype="application/json"):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def body(self, limit=200 * 1024 * 1024):
        n = int(self.headers.get("Content-Length") or 0)
        if n > limit:
            raise ValueError("too large")
        return self.rfile.read(n) if n else b""

    def body_json(self):
        try:
            return json.loads(self.body(1024 * 1024) or b"{}")
        except Exception:
            return {}

    def is_admin(self):
        return REMOTE_ADMIN or self.client_address[0] in ("127.0.0.1", "::1")

    # routing
    def do_GET(self):
        u = urlparse(self.path)
        p = u.path
        if p in ("/", "/index.html"):
            b = DASHBOARD.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)
        elif p == "/api/status":
            self.send_json(200, status())
        elif p == "/healthcheck":
            self.send_json(200, {"state": "OK"})
        elif p == "/users/auth":
            if sync_auth(self):
                self.send_json(200, {"authorized": "OK"})
            else:
                self.send_json(401, {"code": 2001, "message": "Unauthorized"})
        elif p.startswith("/syncs/progress/"):
            user = sync_auth(self)
            if not user:
                return self.send_json(401, {"code": 2001, "message": "Unauthorized"})
            doc = unquote(p[len("/syncs/progress/"):])
            self.send_json(200, sync_db()["progress"].get(user, {}).get(doc, {}))
        elif p == "/opds.xml" or p.startswith("/opds/") or p.startswith("/files/"):
            if ".." in p:
                return self.send_error(403)
            super().do_GET()
        else:
            self.send_error(404)

    def do_HEAD(self):
        p = urlparse(self.path).path
        if p == "/opds.xml" or p.startswith(("/opds/", "/files/")):
            return super().do_HEAD()
        self.send_error(404)

    def do_POST(self):
        u = urlparse(self.path)
        p, q = u.path, parse_qs(u.query)
        if p == "/users/create":
            d = self.body_json()
            user, key = (d.get("username") or "").strip(), d.get("password") or ""
            if not user or not key:
                return self.send_json(400, {"code": 2003, "message": "Invalid request"})
            with DB_LOCK:
                db = sync_db()
                if user in db["users"]:
                    return self.send_json(402, {"code": 2002, "message": "Username is already registered."})
                if not cfg().get("allow_sync_signup", True):
                    return self.send_json(402, {"code": 2005, "message": "Registration disabled."})
                db["users"][user] = key
                save_json(HOME / "sync.json", db)
            log("Sync: registered user", user)
            return self.send_json(201, {"username": user})
        if not p.startswith("/api/"):
            return self.send_error(404)
        if not self.is_admin():
            return self.send_json(403, {"error": "Use the dashboard on the phone itself."})
        c = cfg()
        if p == "/api/update":
            what = (q.get("what") or ["all"])[0]
            ok = run_update(what if what in ("all", "articles", "books") else "all")
            self.send_json(200, {"started": ok})
        elif p == "/api/nettest":
            threading.Thread(target=net_test, daemon=True).start()
            self.send_json(200, {"started": True})
        elif p == "/api/feeds/add":
            d = self.body_json()
            if not d.get("name") or not str(d.get("url", "")).startswith("http"):
                return self.send_json(400, {"error": "name and http(s) url needed"})
            c["feeds"].append({"cat": d.get("cat") if d.get("cat") in CATS else "other",
                               "name": d["name"][:60], "url": d["url"]})
            save_json(HOME / "config.json", c)
            self.send_json(200, {"ok": True})
        elif p == "/api/feeds/delete":
            i = int(self.body_json().get("index", -1))
            if 0 <= i < len(c["feeds"]):
                c["feeds"].pop(i)
                save_json(HOME / "config.json", c)
            self.send_json(200, {"ok": True})
        elif p == "/api/settings":
            d = self.body_json()
            for k in ("articles_per_feed", "books_per_topic", "keep_days"):
                if k in d:
                    c[k] = max(1, min(100, int(d[k])))
            if "auto_refresh_hours" in d:
                c["auto_refresh_hours"] = max(0.0, float(d["auto_refresh_hours"]))
            for k in ("allow_sync_signup", "auto_setup_x4", "auto_setup_sync"):
                if k in d:
                    c[k] = bool(d[k])
            save_json(HOME / "config.json", c)
            self.send_json(200, {"ok": True})
        elif p == "/api/delete":
            d = self.body_json()
            kind, fname = d.get("kind"), Path(str(d.get("file", ""))).name
            if kind in ("articles", "books", "mine") and fname:
                (HOME / "files" / kind / fname).unlink(missing_ok=True)
                (HOME / "meta" / kind / (fname + ".json")).unlink(missing_ok=True)
                build_catalog()
            self.send_json(200, {"ok": True})
        else:
            self.send_error(404)

    def do_PUT(self):
        u = urlparse(self.path)
        p, q = u.path, parse_qs(u.query)
        if p == "/syncs/progress":
            user = sync_auth(self)
            if not user:
                return self.send_json(401, {"code": 2001, "message": "Unauthorized"})
            d = self.body_json()
            doc = d.get("document")
            if not doc:
                return self.send_json(400, {"code": 2004, "message": "Field 'document' not provided."})
            ts = int(time.time())
            with DB_LOCK:
                db = sync_db()
                db["progress"].setdefault(user, {})[doc] = {
                    "document": doc, "progress": d.get("progress"), "percentage": d.get("percentage"),
                    "device": d.get("device"), "device_id": d.get("device_id"), "timestamp": ts}
                save_json(HOME / "sync.json", db)
            return self.send_json(200, {"document": doc, "timestamp": ts})
        if p == "/api/upload":
            if not self.is_admin():
                return self.send_json(403, {"error": "Use the dashboard on the phone itself."})
            name = Path((q.get("name") or [""])[0]).name
            if not name.lower().endswith(".epub"):
                return self.send_json(400, {"error": "Only .epub files"})
            fname = re.sub(r"[^\w.\- ]+", "_", name)
            data = self.body()
            if not data.startswith(b"PK"):
                return self.send_json(400, {"error": "Not a valid EPUB"})
            (HOME / "files/mine" / fname).write_bytes(data)
            write_meta("mine", fname, {"title": fname[:-5].replace("_", " "), "author": "", "cat": "mine"})
            build_catalog()
            log("Uploaded", fname)
            return self.send_json(200, {"ok": True})
        self.send_error(404)


def net_test():
    log("--- Connection test ---")
    try:
        log("DNS www.gutenberg.org ->", socket.gethostbyname("www.gutenberg.org"))
    except Exception as e:
        log("DNS failed:", short(e))
    for name, fn in FETCHERS:
        for url in ("https://www.gutenberg.org/robots.txt", "https://www.quantamagazine.org/feed/"):
            try:
                n = len(fn(url))
                log(f"{name}: OK {url} ({n} bytes)")
            except ModuleNotFoundError:
                log(f"{name}: not available here")
                break
            except Exception as e:
                log(f"{name}: FAIL {url} -> {short(e)}")
    log("--- end of test ---")


def status():
    c = cfg()
    secs = sections()
    db = sync_db()
    return {
        "busy": STATE["busy"], "task": STATE["task"],
        "last_update": STATE["last_update"], "log": list(LOG)[-60:],
        "port": PORT, "ips": local_ips(),
        "sections": [{"name": t, "kind": k, "items": [{"file": f, "title": m["title"]} for f, m in sel]}
                     for k, _, t, sel in secs],
        "feeds": c["feeds"], "settings": {k: c[k] for k in ("articles_per_feed", "books_per_topic", "keep_days",
                                                            "auto_refresh_hours", "allow_sync_signup",
                                                            "auto_setup_x4", "auto_setup_sync")},
        "sync_users": list(db["users"].keys()),
        "x4": X4, "sync_port": SYNC_PORT,
        "sync_login": {"user": c["sync_user"], "password": c["sync_password"]},
    }


DASHBOARD = r"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Xteink Hub</title>
<style>
:root{--bg:#f4f1ea;--card:#fff;--ink:#1d1d1b;--mute:#6b675e;--acc:#1f5f4a;--line:#ddd7ca}
@media(prefers-color-scheme:dark){:root{--bg:#141413;--card:#1e1e1c;--ink:#ecebe6;--mute:#9b978c;--acc:#5fbf98;--line:#33322e}}
*{box-sizing:border-box}body{margin:0;font:16px/1.45 system-ui,sans-serif;background:var(--bg);color:var(--ink)}
header{padding:20px 16px 8px}h1{margin:0;font-size:22px}header p{margin:4px 0 0;color:var(--mute);font-size:14px}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;margin:12px;padding:14px}
h2{font-size:15px;margin:0 0 10px;text-transform:uppercase;letter-spacing:.04em;color:var(--mute)}
button{font:inherit;border:0;border-radius:10px;padding:12px 14px;background:var(--acc);color:#fff;font-weight:600;width:100%;margin:4px 0}
button.ghost{background:transparent;color:var(--acc);border:1px solid var(--acc)}button.sm{width:auto;padding:6px 10px;font-size:13px;margin:0}
button:disabled{opacity:.5}.row{display:flex;gap:8px}.row>*{flex:1}
code{display:block;font:15px ui-monospace,monospace;background:var(--bg);border:1px solid var(--line);border-radius:8px;padding:10px;word-break:break-all;margin:6px 0}
.tag{font-size:12px;color:var(--acc);font-weight:600}.mute{color:var(--mute);font-size:13px}
pre{max-height:220px;overflow:auto;font-size:12px;background:var(--bg);padding:8px;border-radius:8px;margin:8px 0 0;white-space:pre-wrap}
details{border-top:1px solid var(--line);padding:8px 0}summary{cursor:pointer;font-weight:600}
li{margin:4px 0;display:flex;justify-content:space-between;gap:8px;align-items:center}ul{padding:0;list-style:none;margin:6px 0}
input,select{font:inherit;width:100%;padding:9px;border:1px solid var(--line);border-radius:8px;background:var(--bg);color:var(--ink);margin:3px 0}
label{font-size:13px;color:var(--mute)}.dot{display:inline-block;width:9px;height:9px;border-radius:50%;background:var(--acc);margin-right:6px}
.busy .dot{background:#d08a2a;animation:p 1s infinite}@keyframes p{50%{opacity:.3}}
</style></head><body>
<header><h1>Xteink Hub</h1><p id="st"><span class="dot"></span>Running</p></header>

<div class="card" id="andr" style="display:none"><h2>App</h2><div class="row">
<button class="ghost" onclick="Android.hotspot()">Hotspot settings</button>
<button class="ghost" onclick="if(confirm('Stop the server and close the app?'))Android.stop()">Stop server</button></div></div>

<div class="card"><h2>Connect the X4</h2>
<div id="x4" style="font-weight:600;margin-bottom:6px"></div>
<div class="mute">1. Turn on <b>this phone's</b> hotspot (2.4 GHz). Don't connect the phone to the X4's Wi-Fi.<br>
2. On the X4: <b>File Transfer → Join network</b> (not "Create hotspot") → pick the phone's hotspot.<br>
3. Wait for ✓ here (a few seconds), exit File Transfer, open <b>OPDS Browser → Xteink Hub</b>.</div>
<details><summary>Manual setup / addresses</summary><div id="ips"></div><div class="mute" id="slogin"></div></details></div>

<div class="card"><h2>2 · Get reading material</h2>
<button onclick="upd('all')" id="b1">Update everything</button>
<div class="row"><button class="ghost" onclick="upd('articles')">Articles only</button>
<button class="ghost" onclick="upd('books')">Books only</button></div>
<div class="mute" id="last"></div><pre id="log"></pre>
<button class="ghost" onclick="post('/api/nettest')">Test internet connection</button></div>

<div class="card"><h2>Add your own EPUB</h2>
<input type="file" id="file" accept=".epub" multiple><button class="ghost" onclick="upload()">Upload to catalog</button></div>

<div class="card"><h2>Library</h2><div id="lib"></div></div>

<div class="card"><h2>Feeds</h2><ul id="feeds"></ul>
<details><summary>Add a feed</summary>
<label>Name</label><input id="fn"><label>RSS URL</label><input id="fu" placeholder="https://...">
<label>Category</label><select id="fc"><option value="scifi">Sci-Fi</option><option value="science">Science</option><option value="other">Other</option></select>
<button onclick="addFeed()">Add feed</button></details></div>

<div class="card"><h2>Settings</h2>
<div class="row"><div><label>Articles per feed</label><input id="s_a" type="number"></div>
<div><label>Books per topic</label><input id="s_b" type="number"></div></div>
<div class="row"><div><label>Keep articles (days)</label><input id="s_k" type="number"></div>
<div><label>Auto-update every (h, 0=off)</label><input id="s_h" type="number" step="0.5"></div></div>
<label><input type="checkbox" id="s_x4" style="width:auto"> Auto-set up the X4 when it connects</label><br>
<label><input type="checkbox" id="s_ks" style="width:auto"> Also set up KOReader sync on the X4</label><br>
<label><input type="checkbox" id="s_su" style="width:auto"> Allow new sync accounts</label>
<button class="ghost" onclick="saveS()">Save settings</button>
<div class="mute" id="users"></div></div>

<script>
let S={};if(window.Android)document.getElementById('andr').style.display='block';
const $=id=>document.getElementById(id);
const post=(u,d)=>fetch(u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d||{})}).then(r=>r.json());
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
async function load(full){
  S=await fetch('/api/status').then(r=>r.json());
  document.body.className=S.busy?'busy':'';
  $('st').innerHTML='<span class="dot"></span>'+(S.busy?esc(S.task)+'…':'Running · port '+S.port);
  ['b1'].forEach(i=>$(i).disabled=S.busy);
  $('last').textContent=(S.last_update?'Last update: '+new Date(S.last_update*1000).toLocaleString():'First download starts automatically when the phone has internet.')+(S.settings.auto_refresh_hours>0?' · auto-updates every '+S.settings.auto_refresh_hours+' h':'');
  const lg=$('log');lg.textContent=S.log.join('\n');lg.scrollTop=1e9;
  $('ips').innerHTML=S.ips.map(i=>`<div style="margin-top:10px"><span class="tag">${i.hotspot?'HOTSPOT':'WI-FI'} · ${esc(i.iface)}</span>
   <div class="mute">OPDS server URL</div><code>http://${i.ip}:${S.port}/opds.xml</code>
   <div class="mute">KOReader Sync server URL</div><code>http://${i.ip}:${S.sync_port}</code></div>`).join('');
  $('x4').textContent=S.x4.msg; $('x4').style.color=S.x4.ok?'var(--acc)':'';
  $('slogin').textContent=S.sync_login.password?('Sync login: '+S.sync_login.user+' / '+S.sync_login.password):'';
  if(!full)return;
  $('lib').innerHTML=S.sections.map(s=>`<details><summary>${esc(s.name)} (${s.items.length})</summary><ul>${
    s.items.map(it=>`<li><span>${esc(it.title)}</span><button class="sm ghost" onclick="del('${s.kind}','${esc(it.file)}')">✕</button></li>`).join('')||'<li class="mute">Empty</li>'}</ul></details>`).join('');
  $('feeds').innerHTML=S.feeds.map((f,i)=>`<li><span>${esc(f.name)} <span class="mute">· ${esc(f.cat)}</span></span><button class="sm ghost" onclick="delFeed(${i})">✕</button></li>`).join('');
  const st=S.settings;$('s_a').value=st.articles_per_feed;$('s_b').value=st.books_per_topic;$('s_k').value=st.keep_days;$('s_h').value=st.auto_refresh_hours;$('s_su').checked=st.allow_sync_signup;$('s_x4').checked=st.auto_setup_x4;$('s_ks').checked=st.auto_setup_sync;
  $('users').textContent='Sync accounts: '+(S.sync_users.join(', ')||'none yet — register from the X4');
}
async function upd(w){await post('/api/update?what='+w);load()}
async function del(k,f){if(confirm('Delete '+f+'?')){await post('/api/delete',{kind:k,file:f});load(1)}}
async function delFeed(i){if(confirm('Remove this feed?')){await post('/api/feeds/delete',{index:i});load(1)}}
async function addFeed(){const r=await post('/api/feeds/add',{name:$('fn').value,url:$('fu').value,cat:$('fc').value});if(r.error)alert(r.error);else{$('fn').value=$('fu').value='';load(1)}}
async function saveS(){await post('/api/settings',{articles_per_feed:$('s_a').value,books_per_topic:$('s_b').value,keep_days:$('s_k').value,auto_refresh_hours:$('s_h').value,allow_sync_signup:$('s_su').checked,auto_setup_x4:$('s_x4').checked,auto_setup_sync:$('s_ks').checked});alert('Saved');load(1)}
async function upload(){for(const f of $('file').files){const r=await fetch('/api/upload?name='+encodeURIComponent(f.name),{method:'PUT',body:f}).then(r=>r.json());if(r.error)alert(f.name+': '+r.error)}$('file').value='';load(1)}
let wasBusy=false;load(1);setInterval(async()=>{await load(0);if(wasBusy&&!S.busy)load(1);wasBusy=S.busy},2500);
</script></body></html>"""


def serve(home):
    """Entry point used by the Android app."""
    global HOME
    HOME = Path(home)
    main()


def main():
    dirs()
    cfg()
    STATE["last_update"] = load_json(HOME / "state.json", {}).get("last_update")
    build_catalog()
    threading.Thread(target=auto_refresher, daemon=True).start()
    threading.Thread(target=x4_watcher, daemon=True).start()
    try:
        sync_srv = ThreadingHTTPServer(("0.0.0.0", SYNC_PORT), Handler)
        threading.Thread(target=sync_srv.serve_forever, daemon=True).start()
    except OSError as e:
        log(f"Sync port {SYNC_PORT} busy:", e)
    try:
        srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    except OSError as e:
        log(f"Port {PORT} is busy (is the Termux version running? run xhub-stop):", e)
        raise
    log(f"Xteink Hub running. Dashboard: http://127.0.0.1:{PORT}/")
    for i in local_ips():
        log(f"  X4 OPDS: http://{i['ip']}:{PORT}/opds.xml   Sync: http://{i['ip']}:{PORT}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
